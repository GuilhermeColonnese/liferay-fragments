function loadFavorites() {
    const favorites = JSON.parse(localStorage.getItem('favorites')) || {};
    document.querySelectorAll('.service, .system').forEach((item) => {
        const star = item.querySelector('.favorite-icon');
        if (favorites[item.getAttribute('data-id')]) {
            star.classList.add('active');
        }
    });
    updateFavoritesTab();
}

function saveFavorite(item) {
    const favorites = JSON.parse(localStorage.getItem('favorites')) || {};
    const itemId = item.getAttribute('data-id');
    if (item.querySelector('.favorite-icon').classList.contains('active')) {
        favorites[itemId] = true;
    } else {
        delete favorites[itemId];
    }
    localStorage.setItem('favorites', JSON.stringify(favorites));
    updateFavoritesTab();
}

function updateFavoritesTab() {
    const favoritesContent = document.querySelector('.favorites');
    favoritesContent.innerHTML = '';
    const favorites = JSON.parse(localStorage.getItem('favorites')) || {};
    document.querySelectorAll('.service, .system').forEach((item) => {
        if (favorites[item.getAttribute('data-id')]) {
            const clone = item.cloneNode(true);
            clone.querySelector('.favorite-icon').addEventListener('click', function(e) {
                e.stopPropagation();
                this.classList.toggle('active');
                saveFavorite(clone);
            });
            favoritesContent.appendChild(clone);
        }
    });
}

document.querySelectorAll('.service, .system').forEach(item => {
    const star = document.createElement('i');
    star.classList.add('far', 'fa-star', 'favorite-icon');
    item.appendChild(star);

    star.addEventListener('click', function(e) {
        e.stopPropagation();
        this.classList.toggle('active');
        saveFavorite(item);
    });
});

document.querySelectorAll('.tab2').forEach(tab => {
    tab.addEventListener('click', function() {
        document.querySelectorAll('.tab2').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab2-content').forEach(c => c.classList.remove('active'));

        tab.classList.add('active');
        document.querySelector('.' + tab.getAttribute('data-tab')).classList.add('active');
    });
});

document.addEventListener('DOMContentLoaded', loadFavorites);